import React, { useState } from 'react';
import { View, Switch, Text, StyleSheet } from 'react-native';

const App = () => {
  const [isEnabled, setIsEnabled] = useState(false);

  const toggleSwitch = () => {
    setIsEnabled(previousState => !previousState);
  };

  return (
    <View style={[styles.container, { backgroundColor: isEnabled ? 'yellow' : 'black' }]}>
      <Switch
        trackColor={{ false: 'black', true: 'yellow' }}
        thumbColor={isEnabled ? 'green' : 'white'}
        ios_backgroundColor="#3e3e3e"
        onValueChange={toggleSwitch}
        value={isEnabled}
      />
      <Text style={styles.switchText}>{isEnabled ? 'Switch is ON' : 'Switch is OFF'}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  switchText: {
    color: 'white',
    fontSize: 25,
    marginTop: 10,
  },
});

export default App;